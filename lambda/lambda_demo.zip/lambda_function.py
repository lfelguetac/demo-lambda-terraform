def lambda_handler(event, context):
    # Aquí va tu código
    mensaje = "Hola, Colbun!"
    return {
        'statusCode': 200,
        'body': mensaje
    }